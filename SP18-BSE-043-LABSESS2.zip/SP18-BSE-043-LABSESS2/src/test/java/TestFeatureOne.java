import org.junit.Assert;
import org.junit.Test;

public class TestFeatureOne {
    @Test
    public void testFirstFeature()
    {
        Assert.assertTrue(true);
    }
}
