import org.junit.Assert;
import org.junit.Test;

public class TestFeatureTwo {
    @Test
    public void testSecondFeature()
    {
        Assert.assertTrue(true);
    }
}
